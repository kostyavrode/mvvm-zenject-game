﻿using UI.ViewModel;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

namespace UI.View
{
    public class SettingsView : MonoBehaviour
    {
        [SerializeField] private Slider volumeSlider;
        [SerializeField] private Toggle vibrateToggle;
        [SerializeField] private Button saveButton;
        [SerializeField] private Button backButton;
        
        private SettingsViewModel _viewModel;

        public void Initialize(SettingsViewModel viewModel)
        {
            _viewModel = viewModel;
            
            _viewModel.Volume.Subscribe(value=>volumeSlider.value = value).AddTo(this);
            _viewModel.IsVibrate.Subscribe((bool value) =>vibrateToggle.isOn = value).AddTo(this);
            
            volumeSlider.onValueChanged.AddListener(_viewModel.UpdateVolume);
            vibrateToggle.onValueChanged.AddListener(_viewModel.UpdateIsVibrate);
            saveButton.onClick.AddListener(_viewModel.SaveSettings);
            backButton.onClick.AddListener(() =>Debug.Log("Back to menu"));
        }
    }
}