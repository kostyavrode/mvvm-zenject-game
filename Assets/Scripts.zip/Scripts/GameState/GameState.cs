﻿namespace GameState
{
    public enum GameStates
    {
        Menu,
        Playing,
        Pause,
        Finish
    }
}